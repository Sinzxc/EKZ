﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace ServerLib
{
    public class Server
    {
        //log things
        static FileStream log;
        static string time1 = DateTime.Now.ToString("dd.MM.yy HH.mm.ss");
        static string time2 = DateTime.Now.ToString("HH.mm.ss");
        //Socket things
        static IPHostEntry ipHost = Dns.GetHostEntry("localhost");
        static IPAddress ipAddr = ipHost.AddressList[0];
        static IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 8888);
        static Socket sock1 = new Socket(ipAddr.AddressFamily,SocketType.Stream, ProtocolType.Tcp);
        //vars
        static int sumCost = 0, donate, life, faith, line;
        
        public void Start()
        {
            sock1.Bind(ipEndPoint);

            log = new FileStream($"registration_marathon-[{time1}].txt", FileMode.Create, FileAccess.Write);
            string str = "Server started";
            byte[] str2 = Encoding.UTF8.GetBytes($"{str} at [{time1}]\n");
            log.WriteAsync(str2, 0, str2.Length);
            Console.WriteLine(str);
        }

        public void ReciveSend()
        {
            try
            {
                sock1.Listen(10);
                while(true)
                {
                    Socket sock2 = sock1.Accept();
                    byte[] bytes = new byte[1024];
                    sock2.Receive(bytes);
                    string data = Encoding.UTF8.GetString(bytes);
                    Console.WriteLine($"Запрос от клиента:{data}\n\n");
                    string[] msg = data.Replace("{", "").Replace("}", "").Split(',');
                    msg[11] = msg[11][0]+"";

                    byte[] dataLog = Encoding.UTF8.GetBytes($"{data}\n");
                    log.WriteAsync(dataLog, 0, dataLog.Length);

                    if (msg[3] == "1")
                        sumCost += 100;
                    else
                        sumCost += 50;
                    sumCost += 150;
                    if (msg[7] == "1")
                        sumCost += 300;
                    if (msg[8] == "1")
                        sumCost += 300;

                    life = Convert.ToInt32(msg[9]);
                    faith = Convert.ToInt32(msg[10]);
                    line = Convert.ToInt32(msg[11]);
                    donate = sumCost / (life + faith + line);
                    byte[] donatus = Encoding.Default.GetBytes($"Сумма пожертвований от {msg[0]} {msg[1]} {msg[2]}: {sumCost}p [{time2}]\n");
                    log.WriteAsync(donatus, 0, donatus.Length);

                    string reply = "Ваш запрос обработан";
                    byte[] rep = Encoding.UTF8.GetBytes(reply);
                    Console.WriteLine("Отправляем ответ клиенту");
                    sock2.Send(rep);
                    break;

                }    
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            
        }

        public void Stop() 
        { 
            try
            {
                string str = "Server stopped";
                byte[] logEnd = Encoding.UTF8.GetBytes($"{str} at [{time1}]");
                log.WriteAsync(logEnd, 0, logEnd.Length);

                sock1.Shutdown(SocketShutdown.Both);
                sock1.Close();
                Console.WriteLine(str);
            }
            catch(Exception e) { Console.WriteLine(e.Message.ToString()); }
        }
    }
}
