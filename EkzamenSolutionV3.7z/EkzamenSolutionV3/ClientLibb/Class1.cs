﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
namespace ClientLibb
{
    public class Client
    {
        static IPHostEntry ipHost = Dns.GetHostEntry("localhost");
        static IPAddress ipAddr = ipHost.AddressList[0];
        static IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 8888);
        static Socket sock1 = new Socket(ipAddr.AddressFamily,SocketType.Stream,ProtocolType.Tcp);

        public void Connect()
        {
            sock1.Connect(ipEndPoint);

        }

        public void SendRecive(string message)
        {
            try
            {
                
                byte[] msg = Encoding.UTF8.GetBytes(message);
                sock1.Send(msg);
                byte[] bytes = new byte[1024];
                sock1.Receive(bytes);
                string reply = Encoding.UTF8.GetString(bytes);
                Console.WriteLine(reply);
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }

        }

        public void Disconnect() 
        { 
            try
            {
                sock1.Disconnect(false);
                Console.WriteLine("Завершение работы");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
