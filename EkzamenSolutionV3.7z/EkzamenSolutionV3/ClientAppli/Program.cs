﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientLibb;
namespace ClientAppli
{
    class Program
    {
        static string secName, name, midName;
        static bool YesNo = false;
        static int marafon = 0, hmarafon = 0, marafons;
        static int rifd = 1, jacket = 1, bottle = 0, bandana = 0, tovars = 0;
        static int fond, _fond, life, faith, line;
        static string message = null;





        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваше ФИО");
            secName = Console.ReadLine();
            name = Console.ReadLine();
            midName = Console.ReadLine();
            Console.WriteLine("Вводите в ответах только предложенные варианты ответа");
            Console.WriteLine("Выбирите тип марафона:\n1)Марафон - 100p \n2)Полумарафон - 50p");
            marafons = Convert.ToInt32(Console.ReadLine());
            switch(marafon)
            {
                case 1:
                    marafon = 1; hmarafon = 0; break;
                case 2:
                    marafon = 0; hmarafon = 1; break;
            }
            Console.WriteLine("Следующие товары добавлены к вам в корзину:\nRIFD-браслет - 50р\nКуртка - 100 р\nВыбирите дополнительные аксессуары:\nОдинаковые аксессуары выбирать нельзя!\n1)Бутылка воды - 300p \n2)Бандаана - 300p\n3)Не требуется");
            do
            {
                tovars = Convert.ToInt32(Console.ReadLine());

                switch (tovars)
                {
                    case 1:
                        bottle = 1; break;
                    case 2:
                        bandana = 1; break;
                    case 3:
                        tovars = 4; break;
                }
            } while (tovars < 3);
            

            byte k = 0;
            Console.WriteLine("Выбирите фонд, куда будут пожертвованы потраченные вами средства:\n1)Подари жизнь\n2)Вера\n3)Линия жизни");
            do
            {
                fond = Convert.ToInt32(Console.ReadLine());
                switch (fond)
                {
                    case 1:
                        life = 1; break;
                    case 2:
                        faith = 1; break;
                    case 3:
                        line = 1; break;
                }
                k++;
                if ((life == 1 || faith == 1|| line == 1) && k <= 2)
                {
                    Console.WriteLine("Вы желаете выбрать ещё один фонд для ваших пожертвований?\n1)Да\n2)Нет");
                    _fond = Convert.ToInt32(Console.ReadLine());
                    switch(_fond)
                    {
                        case 1:
                            break;
                        case 2:
                            YesNo = true; break;
                    }
                }
            } while (YesNo == false);

            message = $"{{{secName},{name},{midName}}},{{{marafon},{hmarafon}}},{{{rifd},{jacket},{bottle},{bandana}}},{{{life},{faith},{line}}}";
            Console.WriteLine("Отправляем запрос на сервер");
            Client cl = new Client();
            cl.Connect();
            
            cl.SendRecive(message);
            Console.WriteLine("Для завершения работы нажмите любую кнопку");
            cl.Disconnect();
            Console.ReadLine();
        }
    }
}
