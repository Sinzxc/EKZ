﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServerLib;

namespace ServerAppli
{
    class Program
    {
        static void Main(string[] args)
        {
            Server serv = new Server();
            serv.Start();
            serv.ReciveSend();
            Console.WriteLine("Нажмите кнопку для завершения работы");
            Console.ReadLine();
            serv.Stop();
            Console.ReadLine();
        }
    }
}
